<?php
/**
 * Migration 1.5.102 → 1.5.103
 * Creates data files for REST API and white-label system.
 */

$dataPath = defined('DATA_PATH') ? DATA_PATH : __DIR__ . '/../data';

// Empty JSON arrays
foreach (['audit-log.json', 'contacts.json', 'landing-pages.json', 'media.json'] as $file) {
    $path = $dataPath . '/' . $file;
    if (!file_exists($path)) {
        file_put_contents($path, '[]', LOCK_EX);
    }
}

// Empty JSON objects
foreach (['api_rate_limits.json', 'navigation.json', 'settings.json'] as $file) {
    $path = $dataPath . '/' . $file;
    if (!file_exists($path)) {
        file_put_contents($path, '{}', LOCK_EX);
    }
}
