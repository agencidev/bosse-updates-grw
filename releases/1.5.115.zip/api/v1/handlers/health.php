<?php
declare(strict_types=1);
/**
 * Health Check Handler
 * No authentication required. For monitoring and uptime checks.
 */

function handle_health(string $method): never {
    if ($method !== 'GET') {
        api_error(405, 'Method not allowed', allowed: 'GET');
    }

    $checks = [
        'data_writable'    => is_writable(DATA_PATH),
        'uploads_writable' => is_writable(UPLOADS_PATH),
        'content_exists'   => file_exists(DATA_PATH . '/content.json'),
        'projects_exists'  => file_exists(DATA_PATH . '/projects.json'),
    ];

    $healthy = !in_array(false, $checks, true);

    http_response_code($healthy ? 200 : 503);
    header('Cache-Control: no-store');

    echo json_encode([
        'status'    => $healthy ? 'healthy' : 'degraded',
        'version'   => defined('BOSSE_VERSION') ? BOSSE_VERSION : 'unknown',
        'timestamp' => date('c'),
        'checks'    => $checks,
    ], JSON_PRETTY_PRINT);
    exit;
}
