<?php
declare(strict_types=1);
/**
 * SEO API Handler
 * Wrapper around content.json → home key for meta_title and meta_description
 */

function handle_seo(string $method, ?string $identifier): void {
    if ($identifier !== null) {
        api_error(404, 'Not found');
    }

    $file = DATA_PATH . '/content.json';

    match($method) {
        'GET'  => seo_get($file),
        'PUT'  => seo_put($file),
        default => api_error(405, 'Method not allowed', allowed: 'GET, PUT'),
    };
}

function seo_get(string $file): void {
    api_etag($file);

    $data = [];
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true) ?? [];
    }

    $home = $data['home'] ?? [];

    api_success([
        'meta_title'       => $home['meta_title'] ?? '',
        'meta_description' => $home['meta_description'] ?? '',
    ]);
}

function seo_put(string $file): void {
    $body = api_get_json_body();
    $errors = [];

    if (!isset($body['meta_title']) || !validate_text($body['meta_title'], 1, 200)) {
        $errors['meta_title'] = 'meta_title is required (1-200 characters)';
    }
    if (!isset($body['meta_description']) || !validate_text($body['meta_description'], 1, 500)) {
        $errors['meta_description'] = 'meta_description is required (1-500 characters)';
    }

    if (!empty($errors)) {
        api_error(422, 'Validation failed', details: $errors);
    }

    $seo = [
        'meta_title'       => sanitize_text($body['meta_title']),
        'meta_description' => sanitize_text($body['meta_description']),
    ];

    $ok = atomic_json_update($file, function(array $data) use ($seo): array {
        $data['home'] = array_merge($data['home'] ?? [], $seo);
        return $data;
    });

    if (!$ok) {
        api_error(500, 'Failed to update SEO data');
    }

    audit_log('api.seo.put', 'Updated SEO meta', 'api');
    api_success($seo);
}
