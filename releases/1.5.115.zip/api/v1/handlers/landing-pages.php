<?php
declare(strict_types=1);
/**
 * Landing Pages API Handler
 * Full CRUD on landing-pages.json
 */

const LANDING_PAGE_SECTION_TYPES = [
    'html', 'feature-grid-4', 'feature-grid-3', 'feature-grid-2',
    'solution-features', 'problem-cards', 'numbered-cards-4',
    'stats-3', 'steps-3', 'related-pages',
];

function handle_landing_pages(string $method, ?string $identifier): void {
    $file = DATA_PATH . '/landing-pages.json';

    match(true) {
        // GET /landing-pages — list all
        $method === 'GET' && $identifier === null => lp_list($file),

        // GET /landing-pages/{slug} — get one
        $method === 'GET' && $identifier !== null => lp_get($file, $identifier),

        // POST /landing-pages — create
        $method === 'POST' && $identifier === null => lp_create($file),

        // PUT /landing-pages/{slug} — replace
        $method === 'PUT' && $identifier !== null => lp_put($file, $identifier),

        // PATCH /landing-pages/{slug} — partial update
        $method === 'PATCH' && $identifier !== null => lp_patch($file, $identifier),

        // DELETE /landing-pages/{slug} — delete
        $method === 'DELETE' && $identifier !== null => lp_delete($file, $identifier),

        default => api_error(405, 'Method not allowed', allowed: 'GET, POST, PUT, PATCH, DELETE'),
    };
}

function lp_list(string $file): void {
    api_etag($file);

    $pages = [];
    if (file_exists($file)) {
        $pages = json_decode(file_get_contents($file), true) ?? [];
    }

    // Return slug + meta only for list view
    $summary = array_map(fn($p) => [
        'slug'      => $p['slug'] ?? '',
        'meta'      => $p['meta'] ?? [],
        'bodyClass' => $p['bodyClass'] ?? '',
    ], $pages);

    api_success($summary, ['total' => count($pages)]);
}

function lp_get(string $file, string $slug): void {
    api_etag($file);

    $pages = [];
    if (file_exists($file)) {
        $pages = json_decode(file_get_contents($file), true) ?? [];
    }

    foreach ($pages as $page) {
        if (($page['slug'] ?? '') === $slug) {
            api_success($page);
            return;
        }
    }

    api_error(404, "Landing page '$slug' not found");
}

function lp_create(string $file): void {
    $body = api_get_json_body();
    $errors = validate_landing_page($body);
    if (!empty($errors)) {
        api_error(422, 'Validation failed', details: $errors);
    }

    $slug = $body['slug'] ?? generateSlug($body['meta']['title'] ?? 'page');
    $body['slug'] = sanitize_text($slug);

    // Check for duplicate slug
    $existing = [];
    if (file_exists($file)) {
        $existing = json_decode(file_get_contents($file), true) ?? [];
    }
    foreach ($existing as $page) {
        if (($page['slug'] ?? '') === $body['slug']) {
            api_error(409, "Landing page with slug '{$body['slug']}' already exists");
        }
    }

    // Sanitize meta
    if (isset($body['meta'])) {
        $body['meta'] = sanitize_landing_meta($body['meta']);
    }

    // Validate section types
    if (isset($body['sections'])) {
        validate_sections($body['sections']);
    }

    $ok = atomic_json_update($file, function(array $data) use ($body): array {
        $data[] = $body;
        return $data;
    });

    if (!$ok) {
        api_error(500, 'Failed to save landing page');
    }

    audit_log('api.landing_page.create', "Created landing page: {$body['slug']}", 'api');
    api_success($body, status: 201);
}

function lp_put(string $file, string $slug): void {
    $body = api_get_json_body();
    $errors = validate_landing_page($body);
    if (!empty($errors)) {
        api_error(422, 'Validation failed', details: $errors);
    }

    $body['slug'] = $slug;

    if (isset($body['meta'])) {
        $body['meta'] = sanitize_landing_meta($body['meta']);
    }
    if (isset($body['sections'])) {
        validate_sections($body['sections']);
    }

    $found = false;

    $ok = atomic_json_update($file, function(array $data) use ($slug, $body, &$found): array {
        foreach ($data as $i => $page) {
            if (($page['slug'] ?? '') === $slug) {
                $found = true;
                $data[$i] = $body;
                break;
            }
        }
        return $data;
    });

    if (!$found) {
        api_error(404, "Landing page '$slug' not found");
    }
    if (!$ok) {
        api_error(500, 'Failed to save landing page');
    }

    audit_log('api.landing_page.put', "Replaced landing page: $slug", 'api');
    api_success($body);
}

function lp_patch(string $file, string $slug): void {
    $body = api_get_json_body();

    if (isset($body['meta'])) {
        $body['meta'] = sanitize_landing_meta($body['meta']);
    }
    if (isset($body['sections'])) {
        validate_sections($body['sections']);
    }

    $found = false;
    $result = null;

    $ok = atomic_json_update($file, function(array $data) use ($slug, $body, &$found, &$result): array {
        foreach ($data as $i => $page) {
            if (($page['slug'] ?? '') === $slug) {
                $found = true;
                // Don't allow changing the slug via PATCH
                unset($body['slug']);
                // Shallow merge
                $data[$i] = array_merge($page, $body);
                // Deep merge meta if both exist
                if (isset($body['meta']) && isset($page['meta'])) {
                    $data[$i]['meta'] = array_merge($page['meta'], $body['meta']);
                }
                $result = $data[$i];
                break;
            }
        }
        return $data;
    });

    if (!$found) {
        api_error(404, "Landing page '$slug' not found");
    }
    if (!$ok) {
        api_error(500, 'Failed to save landing page');
    }

    audit_log('api.landing_page.patch', "Updated landing page: $slug", 'api');
    api_success($result);
}

function lp_delete(string $file, string $slug): void {
    $found = false;

    $ok = atomic_json_update($file, function(array $data) use ($slug, &$found): array {
        foreach ($data as $i => $page) {
            if (($page['slug'] ?? '') === $slug) {
                $found = true;
                array_splice($data, $i, 1);
                break;
            }
        }
        return $data;
    });

    if (!$found) {
        api_error(404, "Landing page '$slug' not found");
    }
    if (!$ok) {
        api_error(500, 'Failed to delete landing page');
    }

    audit_log('api.landing_page.delete', "Deleted landing page: $slug", 'api');
    api_success(null);
}

function validate_landing_page(array $data): array {
    $errors = [];
    if (empty($data['meta']['title'])) {
        $errors['meta.title'] = 'Meta title is required';
    }
    return $errors;
}

function validate_sections(array $sections): void {
    foreach ($sections as $i => $section) {
        $type = $section['type'] ?? null;
        if ($type !== null && !in_array($type, LANDING_PAGE_SECTION_TYPES, true)) {
            api_error(422, 'Validation failed', details: [
                "sections[$i].type" => "Invalid section type: $type. Allowed: " . implode(', ', LANDING_PAGE_SECTION_TYPES)
            ]);
        }
    }
}

function sanitize_landing_meta(array $meta): array {
    if (isset($meta['title'])) {
        $meta['title'] = sanitize_text($meta['title']);
    }
    if (isset($meta['description'])) {
        $meta['description'] = sanitize_text($meta['description']);
    }
    if (isset($meta['ogImage'])) {
        $meta['ogImage'] = sanitize_text($meta['ogImage']);
    }
    return $meta;
}
