<?php
declare(strict_types=1);
/**
 * Content API Handler
 * GET/PUT/PATCH operations on content.json
 */

// Allowed top-level keys
const CONTENT_ALLOWED_KEYS = [
    'hero', 'home', 'footer', 'about', 'services', 'contact',
    'demo', 'blog', 'seo', 'meta', 'settings', 'navigation',
];

function handle_content(string $method, ?string $identifier): void {
    $file = DATA_PATH . '/content.json';

    match(true) {
        // GET /content — return all content
        $method === 'GET' && $identifier === null => content_get_all($file),

        // GET /content/{key} — return one key
        $method === 'GET' && $identifier !== null => content_get_key($file, $identifier),

        // PUT /content/{key} — replace entire key
        $method === 'PUT' && $identifier !== null => content_put_key($file, $identifier),

        // PATCH /content/{key} — partial update
        $method === 'PATCH' && $identifier !== null => content_patch_key($file, $identifier),

        default => api_error(405, 'Method not allowed', allowed: 'GET, PUT, PATCH'),
    };
}

function content_get_all(string $file): void {
    api_etag($file);

    $data = [];
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true) ?? [];
    }
    api_success($data);
}

function content_get_key(string $file, string $key): void {
    if (!in_array($key, CONTENT_ALLOWED_KEYS, true)) {
        api_error(400, "Invalid content key: $key");
    }

    api_etag($file);

    $data = [];
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true) ?? [];
    }

    if (!isset($data[$key])) {
        api_error(404, "Content key '$key' not found");
    }

    api_success($data[$key]);
}

function content_put_key(string $file, string $key): void {
    if (!in_array($key, CONTENT_ALLOWED_KEYS, true)) {
        api_error(400, "Invalid content key: $key");
    }

    $body = api_get_json_body();
    if (!is_array($body)) {
        api_error(422, 'Request body must be a JSON object');
    }

    // Sanitize all string values
    $body = sanitize_content_data($body);

    $ok = atomic_json_update($file, function(array $data) use ($key, $body): array {
        $data[$key] = $body;
        return $data;
    });

    if (!$ok) {
        api_error(500, 'Failed to write content');
    }

    audit_log('api.content.put', "Replaced content key: $key", 'api');
    api_success($body);
}

function content_patch_key(string $file, string $key): void {
    if (!in_array($key, CONTENT_ALLOWED_KEYS, true)) {
        api_error(400, "Invalid content key: $key");
    }

    $body = api_get_json_body();
    if (!is_array($body)) {
        api_error(422, 'Request body must be a JSON object');
    }

    $body = sanitize_content_data($body);
    $result = null;

    $ok = atomic_json_update($file, function(array $data) use ($key, $body, &$result): array {
        $existing = $data[$key] ?? [];
        if (!is_array($existing)) {
            $existing = [];
        }
        // Shallow merge
        $data[$key] = array_merge($existing, $body);
        $result = $data[$key];
        return $data;
    });

    if (!$ok) {
        api_error(500, 'Failed to write content');
    }

    audit_log('api.content.patch', "Updated content key: $key", 'api');
    api_success($result);
}

/**
 * Recursively sanitize string values in content data
 */
function sanitize_content_data(array $data): array {
    foreach ($data as $k => $v) {
        if (is_string($v)) {
            $data[$k] = sanitize_text($v);
        } elseif (is_array($v)) {
            $data[$k] = sanitize_content_data($v);
        }
    }
    return $data;
}
