<?php
declare(strict_types=1);
/**
 * Settings API Handler
 * Manage site-wide configuration.
 */

define('SETTINGS_FILE', DATA_PATH . '/settings.json');

const SETTINGS_ALLOWED_KEYS = [
    'site_name', 'site_url', 'site_description', 'contact_email',
    'logo', 'logo_dark', 'favicon',
    'social', 'analytics', 'scripts',
    'footer_text', 'copyright',
];

function handle_settings(string $method, ?string $identifier): void {
    match(true) {
        $method === 'GET' && $identifier === null   => settings_get_all(),
        $method === 'GET' && $identifier !== null    => settings_get_key($identifier),
        $method === 'PUT' && $identifier === null    => settings_put(),
        $method === 'PATCH' && $identifier === null  => settings_patch(),
        default => api_error(405, 'Method not allowed', allowed: 'GET, PUT, PATCH'),
    };
}

function settings_get_all(): void {
    api_etag(SETTINGS_FILE);

    $data = [];
    if (file_exists(SETTINGS_FILE)) {
        $data = json_decode(file_get_contents(SETTINGS_FILE), true) ?? [];
    }

    api_success($data);
}

function settings_get_key(string $key): void {
    if (!in_array($key, SETTINGS_ALLOWED_KEYS, true)) {
        api_error(400, "Invalid settings key: $key. Allowed: " . implode(', ', SETTINGS_ALLOWED_KEYS));
    }

    api_etag(SETTINGS_FILE);

    $data = [];
    if (file_exists(SETTINGS_FILE)) {
        $data = json_decode(file_get_contents(SETTINGS_FILE), true) ?? [];
    }

    if (!isset($data[$key])) {
        api_error(404, "Settings key '$key' not found");
    }

    api_success($data[$key]);
}

function settings_put(): void {
    api_check_if_match(SETTINGS_FILE);
    $body = api_get_json_body();

    // Only allow known keys
    $filtered = [];
    foreach ($body as $k => $v) {
        if (in_array($k, SETTINGS_ALLOWED_KEYS, true)) {
            $filtered[$k] = $v;
        }
    }

    $filtered = sanitize_settings_data($filtered);

    $ok = file_put_contents(
        SETTINGS_FILE,
        json_encode($filtered, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
        LOCK_EX
    );

    if ($ok === false) {
        api_error(500, 'Failed to save settings');
    }

    audit_log('api.settings.put', 'Replaced site settings', 'api');
    api_success($filtered);
}

function settings_patch(): void {
    api_check_if_match(SETTINGS_FILE);
    $body = api_get_json_body();

    // Only allow known keys
    $updates = [];
    foreach ($body as $k => $v) {
        if (in_array($k, SETTINGS_ALLOWED_KEYS, true)) {
            $updates[$k] = $v;
        }
    }

    if (empty($updates)) {
        api_error(422, 'No valid fields to update. Allowed keys: ' . implode(', ', SETTINGS_ALLOWED_KEYS));
    }

    $updates = sanitize_settings_data($updates);
    $result  = null;

    $ok = atomic_json_update(SETTINGS_FILE, function (array $data) use ($updates, &$result): array {
        foreach ($updates as $k => $v) {
            // Deep merge for nested objects (social, analytics, scripts)
            if (is_array($v) && isset($data[$k]) && is_array($data[$k])) {
                $data[$k] = array_merge($data[$k], $v);
            } else {
                $data[$k] = $v;
            }
        }
        $result = $data;
        return $data;
    });

    if (!$ok) {
        api_error(500, 'Failed to save settings');
    }

    audit_log('api.settings.patch', 'Updated site settings: ' . implode(', ', array_keys($updates)), 'api');
    api_success($result);
}

function sanitize_settings_data(array $data): array {
    foreach ($data as $k => $v) {
        if (is_string($v)) {
            $data[$k] = sanitize_text($v);
        } elseif (is_array($v)) {
            $data[$k] = sanitize_settings_data($v);
        }
    }
    return $data;
}
