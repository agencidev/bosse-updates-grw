<?php
/**
 * Agency branding helper — CORE file
 * Returns agency config with three-tier priority:
 * 1. config.php AGENCY_* constants (per-site override)
 * 2. agency-defaults.json (shipped with update repo, per-partner)
 * 3. Hardcoded Peys defaults (ultimate fallback)
 */

function agency_config(?string $key = null) {
    static $config = null;
    if ($config === null) {
        // 1. Hardcoded defaults
        $defaults = [
            'name'        => 'PEYS',
            'url'         => 'https://peys.se',
            'logo_light'  => '/assets/images/cms/peys-logo-light.png',
            'logo_dark'   => '/assets/images/cms/peys-logo-dark.png',
            'badge_text'  => 'Sidan drivs och hanteras av',
            'badge_bg'    => '#033234',
            'corner_text' => 'Skapad av oss 🥳',
            'login_tab'   => 'PEYS',
            // CMS theme
            'cms_bg'      => '#033234',
            'cms_accent'  => '#379b83',
            'cms_font'    => 'DM Sans',
            'cms_font_heading' => 'Space Grotesk',
        ];

        // 2. agency-defaults.json (from update repo — partner-specific)
        $jsonPath = (defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__)) . '/agency-defaults.json';
        if (file_exists($jsonPath)) {
            $json = json_decode(file_get_contents($jsonPath), true);
            if (is_array($json)) {
                $defaults = array_merge($defaults, $json);
            }
        }

        // 3. config.php overrides (highest priority)
        $map = [
            'name'        => 'AGENCY_NAME',
            'url'         => 'AGENCY_URL',
            'logo_light'  => 'AGENCY_LOGO_LIGHT',
            'logo_dark'   => 'AGENCY_LOGO_DARK',
            'badge_text'  => 'AGENCY_BADGE_TEXT',
            'badge_bg'    => 'AGENCY_BADGE_BG',
            'corner_text' => 'AGENCY_CORNER_TEXT',
            'login_tab'   => 'AGENCY_LOGIN_TAB',
            'cms_bg'      => 'AGENCY_CMS_BG',
            'cms_accent'  => 'AGENCY_CMS_ACCENT',
            'cms_font'    => 'AGENCY_CMS_FONT',
            'cms_font_heading' => 'AGENCY_CMS_FONT_HEADING',
        ];
        $config = $defaults;
        foreach ($map as $k => $const) {
            if (defined($const)) {
                $config[$k] = constant($const);
            }
        }
    }
    return $key !== null ? ($config[$key] ?? null) : $config;
}

/**
 * Returns a <style> block that overrides CMS colors/fonts based on agency config.
 * Include this in all CMS pages to apply agency theming.
 */
function agency_cms_theme(): string {
    $bg = htmlspecialchars(agency_config('cms_bg'));
    $accent = htmlspecialchars(agency_config('cms_accent'));
    $font = htmlspecialchars(agency_config('cms_font'));
    $fontHeading = htmlspecialchars(agency_config('cms_font_heading'));

    return <<<CSS
<style>
:root { --color-woodsmoke: {$bg}; --color-persimmon: {$accent}; }
body { background-color: {$bg} !important; font-family: '{$font}', sans-serif !important; }
h1, h2, h3, h4, h5, h6 { font-family: '{$fontHeading}', sans-serif !important; }
/* Backgrounds */
.bg-woodsmoke, .admin-bar, [class*="admin-bar"] { background-color: {$bg} !important; }
.bg-persimmon { background-color: {$accent} !important; }
/* Buttons & badges */
.sa-btn--primary, .btn-primary, button[type="submit"],
.admin-bar__btn-logout, [class*="btn--primary"] { background-color: {$accent} !important; color: #fff !important; border-color: {$accent} !important; }
.sa-badge--ok, .badge--ok, [class*="badge--ok"] { background-color: {$accent} !important; color: #fff !important; }
/* Links & accents */
a:not([class]) { color: {$accent}; }
.login-tab.active { background: {$accent} !important; color: #fff !important; }
/* Admin bar border */
.admin-bar { border-bottom-color: rgba(255,255,255,0.1) !important; }
/* Panels */
.sa-panel, [class*="sa-panel"] { border-color: rgba(255,255,255,0.08) !important; }
/* Hover states — icons, cards */
a:hover svg, .card:hover svg, [class*="card"]:hover svg, [class*="stat"]:hover svg { color: {$accent} !important; fill: {$accent} !important; }
a:hover .icon, .card:hover .icon { color: {$accent} !important; }
.hover\:text-persimmon:hover, [class*="hover"][class*="persimmon"]:hover { color: {$accent} !important; }
/* Focus/active states */
input:focus, select:focus, textarea:focus { border-color: {$accent} !important; outline-color: {$accent} !important; }
</style>
CSS;
}

/**
 * Returns Google Fonts <link> tags for CMS fonts.
 */
function agency_cms_fonts(): string {
    $font = agency_config('cms_font');
    $fontHeading = agency_config('cms_font_heading');
    $families = [];
    foreach ([$font, $fontHeading] as $f) {
        if ($f !== 'DM Sans' && $f !== 'Space Grotesk' && $f !== 'System UI' && !in_array($f, $families)) {
            $families[] = $f;
        }
    }
    if (empty($families)) return '';
    $params = [];
    foreach ($families as $f) {
        $params[] = 'family=' . urlencode($f) . ':wght@400;500;600;700';
    }
    $url = 'https://fonts.googleapis.com/css2?' . implode('&', $params) . '&display=swap';
    return '<link href="' . htmlspecialchars($url) . '" rel="stylesheet">';
}
