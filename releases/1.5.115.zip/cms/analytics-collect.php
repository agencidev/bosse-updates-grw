<?php
/**
 * Analytics Collection Endpoint
 * Receives beacon data from tracker.js (public, no auth)
 * Responds with 204 No Content
 */

// Minimal bootstrap — only what we need
require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/analytics-db.php';

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

// Rate limiting: 100 requests per IP per minute
$ipRaw = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$rateFile = DATA_PATH . '/tmp/rate_' . md5($ipRaw) . '.json';
$now = time();
$rateData = [];

if (file_exists($rateFile)) {
    $rateData = json_decode(file_get_contents($rateFile), true) ?: [];
    // Remove entries older than 60 seconds
    $rateData = array_filter($rateData, fn($t) => $t > $now - 60);
}

if (count($rateData) >= 100) {
    http_response_code(429);
    exit;
}

$rateData[] = $now;
$tmpDir = DATA_PATH . '/tmp';
if (!is_dir($tmpDir)) {
    mkdir($tmpDir, 0755, true);
}
@file_put_contents($rateFile, json_encode($rateData), LOCK_EX);

// Read JSON body
$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input) || empty($input['type'])) {
    http_response_code(400);
    exit;
}

// Anonymize IP: SHA-256 with daily salt
$dailySalt = date('Y-m-d') . (defined('SITE_URL') ? SITE_URL : 'bosse');
$ipHash = hash('sha256', $ipRaw . $dailySalt);

// Validate common fields
$sessionId = preg_match('/^[a-f0-9]{8,32}$/', $input['sid'] ?? '') ? $input['sid'] : null;
$visitorId = preg_match('/^[a-f0-9]{8,32}$/', $input['vid'] ?? '') ? $input['vid'] : null;

if (!$sessionId || !$visitorId) {
    http_response_code(400);
    exit;
}

// Validate path
$path = $input['path'] ?? '/';
if (strlen($path) > 500 || !preg_match('#^/[a-zA-Z0-9_./%?&=+\-]*$#', $path)) {
    $path = '/';
}

$type = $input['type'];

try {
    switch ($type) {
        case 'pageview':
            // Parse user agent
            $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
            $deviceType = detect_device_type($ua);
            $browser = detect_browser($ua);
            $os = detect_os($ua);

            // Parse referrer
            $referrer = substr($input['ref'] ?? '', 0, 1000);
            $referrerDomain = '';
            if (!empty($referrer) && filter_var($referrer, FILTER_VALIDATE_URL)) {
                $referrerDomain = parse_url($referrer, PHP_URL_HOST) ?: '';
                // Skip own domain
                if (defined('SITE_URL') && !empty(SITE_URL)) {
                    $ownDomain = parse_url(SITE_URL, PHP_URL_HOST) ?: '';
                    if ($referrerDomain === $ownDomain) {
                        $referrerDomain = '';
                        $referrer = '';
                    }
                }
            }

            // Parse UTM parameters
            $utmSource = substr($input['utm_source'] ?? '', 0, 200);
            $utmMedium = substr($input['utm_medium'] ?? '', 0, 200);
            $utmCampaign = substr($input['utm_campaign'] ?? '', 0, 200);

            // Screen dimensions
            $sw = max(0, min(10000, (int) ($input['sw'] ?? 0)));
            $sh = max(0, min(10000, (int) ($input['sh'] ?? 0)));

            // Create or update session
            analytics_create_session([
                'session_id' => $sessionId,
                'visitor_id' => $visitorId,
                'ip_hash' => $ipHash,
                'user_agent' => substr($ua, 0, 500),
                'device_type' => $deviceType,
                'browser' => $browser,
                'os' => $os,
                'screen_width' => $sw,
                'screen_height' => $sh,
                'referrer' => $referrer,
                'referrer_domain' => $referrerDomain,
                'utm_source' => $utmSource,
                'utm_medium' => $utmMedium,
                'utm_campaign' => $utmCampaign,
                'landing_page' => $path,
            ]);

            // Record pageview
            analytics_record_pageview([
                'session_id' => $sessionId,
                'visitor_id' => $visitorId,
                'path' => $path,
                'title' => substr($input['title'] ?? '', 0, 500),
            ]);
            break;

        case 'heartbeat':
            $scrollDepth = max(0, min(100, (int) ($input['scroll'] ?? 0)));
            $timeOnPage = max(0, min(86400, (int) ($input['time'] ?? 0)));

            analytics_heartbeat([
                'session_id' => $sessionId,
                'path' => $path,
                'scroll_depth' => $scrollDepth,
                'time_on_page' => $timeOnPage,
            ]);
            break;

        case 'clicks':
            $clicks = $input['clicks'] ?? [];
            if (!is_array($clicks) || count($clicks) > 20) {
                break;
            }

            $validClicks = [];
            foreach ($clicks as $click) {
                if (!is_array($click)) continue;
                $validClicks[] = [
                    'x' => max(0, min(100, (float) ($click['x'] ?? 0))),
                    'y' => max(0, min(100, (float) ($click['y'] ?? 0))),
                    'tag' => preg_replace('/[^a-zA-Z0-9]/', '', $click['tag'] ?? ''),
                    'text' => substr($click['text'] ?? '', 0, 100),
                    'vw' => max(0, min(10000, (int) ($click['vw'] ?? 0))),
                    'ph' => max(0, min(100000, (int) ($click['ph'] ?? 0))),
                ];
            }

            if (!empty($validClicks)) {
                analytics_record_clicks($sessionId, $path, $validClicks);
            }
            break;
    }
} catch (\Throwable $e) {
    // Silently fail — never expose errors to client
}

http_response_code(204);
exit;

// ── Helper functions ──

function detect_device_type(string $ua): string {
    $ua = strtolower($ua);
    if (preg_match('/mobile|android.*mobile|iphone|ipod|opera mini|opera mobi/i', $ua)) {
        return 'mobile';
    }
    if (preg_match('/tablet|ipad|android(?!.*mobile)/i', $ua)) {
        return 'tablet';
    }
    return 'desktop';
}

function detect_browser(string $ua): string {
    if (preg_match('/Edg\//i', $ua)) return 'Edge';
    if (preg_match('/OPR\//i', $ua)) return 'Opera';
    if (preg_match('/Chrome\//i', $ua) && !preg_match('/Edg|OPR/i', $ua)) return 'Chrome';
    if (preg_match('/Safari\//i', $ua) && !preg_match('/Chrome|Edg|OPR/i', $ua)) return 'Safari';
    if (preg_match('/Firefox\//i', $ua)) return 'Firefox';
    return 'Other';
}

function detect_os(string $ua): string {
    if (preg_match('/Windows/i', $ua)) return 'Windows';
    if (preg_match('/Macintosh|Mac OS/i', $ua)) return 'macOS';
    if (preg_match('/Linux/i', $ua) && !preg_match('/Android/i', $ua)) return 'Linux';
    if (preg_match('/Android/i', $ua)) return 'Android';
    if (preg_match('/iPhone|iPad|iPod/i', $ua)) return 'iOS';
    return 'Other';
}
