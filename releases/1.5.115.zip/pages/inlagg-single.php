<?php
/**
 * Enskilt inlägg (publik)
 * Visar ett inlägg baserat på slug
 * CORE-fil — skrivs över vid uppdatering.
 * Anpassa design via assets/css/inlagg-single-custom.css (SAFE).
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../security/session.php';
require_once __DIR__ . '/../security/validation.php';
require_once __DIR__ . '/../cms/content.php';
require_once __DIR__ . '/../seo/meta.php';
require_once __DIR__ . '/../seo/schema.php';

// Slug from URL
$slug = trim($_GET['slug'] ?? '');

// Context detection based on URL prefix
$_uri_prefix = $_uri_prefix ?? '/inlagg';
$_back_label = $_back_label ?? 'Tillbaka till inlägg';

// Load projects
$projects_file = __DIR__ . '/../data/projects.json';
$projects = [];
$project = null;

if (file_exists($projects_file)) {
    $json = file_get_contents($projects_file);
    $projects = json_decode($json, true) ?? [];
}

// Find the project
foreach ($projects as $p) {
    if (isset($p['slug']) && $p['slug'] === $slug) {
        if (isset($p['status']) && $p['status'] === 'published') {
            $project = $p;
            break;
        }
        if (is_logged_in()) {
            $project = $p;
            break;
        }
    }
}

// 404 if not found
if (!$project) {
    http_response_code(404);
    if (file_exists(__DIR__ . '/errors/404.php')) {
        include __DIR__ . '/errors/404.php';
        exit;
    }
    echo '<h1>404 - Sidan kunde inte hittas</h1>';
    exit;
}

// Schema.org
function projectSchema($project, $_uri_prefix = '/inlagg') {
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'Article',
        'headline' => $project['title'] ?? '',
        'description' => $project['summary'] ?? '',
        'datePublished' => $project['createdAt'] ?? '',
        'dateModified' => $project['updatedAt'] ?? $project['createdAt'] ?? '',
        'author' => [
            '@type' => 'Organization',
            'name' => SITE_NAME
        ],
        'publisher' => [
            '@type' => 'Organization',
            'name' => SITE_NAME,
            'logo' => [
                '@type' => 'ImageObject',
                'url' => SITE_URL . '/assets/images/logo-dark.png'
            ]
        ],
        'mainEntityOfPage' => [
            '@type' => 'WebPage',
            '@id' => SITE_URL . $_uri_prefix . '/' . ($project['slug'] ?? '')
        ]
    ];

    if (!empty($project['coverImage'])) {
        $schema['image'] = SITE_URL . $project['coverImage'];
    }

    return '<script type="application/ld+json" ' . csp_nonce_attr() . '>' . json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
}
?>
<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php
    generateMeta(
        $project['title'] ?? 'Inlägg',
        $project['summary'] ?? '',
        $project['coverImage'] ?? '/assets/images/og-image.jpg',
        'article',
        [
            'published' => $project['createdAt'] ?? '',
            'modified' => $project['updatedAt'] ?? $project['createdAt'] ?? '',
        ]
    );
    ?>

    <?php if (file_exists(__DIR__ . '/../assets/images/favicon.png')): ?>
    <link rel="icon" type="image/png" href="/assets/images/favicon.png">
    <?php endif; ?>
    <?php if (file_exists(__DIR__ . '/../assets/images/apple-touch-icon.png')): ?>
    <link rel="apple-touch-icon" href="/assets/images/apple-touch-icon.png">
    <?php endif; ?>
    <link rel="stylesheet" href="/assets/css/main.css?v=<?php echo BOSSE_VERSION; ?>">
    <?php if (!empty($project['coverImage'])): ?>
    <link rel="preload" as="image" href="<?php echo htmlspecialchars($project['coverImage'], ENT_QUOTES, 'UTF-8'); ?>">
    <?php endif; ?>
    <?php
    // Custom CSS overrides default completely (SAFE — survives updates)
    if (file_exists(__DIR__ . '/../assets/css/inlagg-single-custom.css')) {
        echo '<link rel="stylesheet" href="/assets/css/inlagg-single-custom.css?v=' . BOSSE_VERSION . '">';
    } else {
        echo '<link rel="stylesheet" href="/assets/css/inlagg-single-default.css?v=' . BOSSE_VERSION . '">';
    }
    ?>
    <?php if (file_exists(__DIR__ . '/../includes/fonts.php')) include __DIR__ . '/../includes/fonts.php'; ?>
    <?php if (file_exists(__DIR__ . '/../includes/analytics.php')) include __DIR__ . '/../includes/analytics.php'; ?>

    <?php echo projectSchema($project, $_uri_prefix); ?>
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-bar.php'; ?>
    <?php include __DIR__ . '/../includes/header.php'; ?>

    <main id="main-content">
        <article class="projekt-single">
            <div class="projekt-single__container" style="max-width: 800px; margin: 0 auto; padding: 0 1.5rem;">
                <!-- Back link -->
                <a href="<?php echo htmlspecialchars($_uri_prefix); ?>" class="projekt-single__back">
                    &larr; <?php echo htmlspecialchars($_back_label); ?>
                </a>

                <?php if (is_logged_in()): ?>
                <div class="projekt-single__admin-bar">
                    <span>
                        <?php if (($project['status'] ?? 'draft') === 'draft'): ?>
                            Detta är ett utkast och visas endast för inloggade
                        <?php else: ?>
                            Du kan redigera detta inlägg
                        <?php endif; ?>
                    </span>
                    <a href="/projects/edit?id=<?php echo urlencode($project['id'] ?? ''); ?>">Redigera</a>
                </div>
                <?php endif; ?>

                <!-- Category -->
                <?php if (!empty($project['category'])): ?>
                    <span class="projekt-single__category"><?php echo htmlspecialchars($project['category']); ?></span>
                <?php endif; ?>

                <!-- Title -->
                <h1 class="projekt-single__title"><?php echo htmlspecialchars($project['title'] ?? 'Utan titel', ENT_QUOTES, 'UTF-8'); ?></h1>

                <!-- Meta -->
                <div class="projekt-single__meta">
                    <?php if (!empty($project['createdAt'])): ?>
                        <span><?php echo date('j M Y', strtotime($project['createdAt'])); ?></span>
                    <?php endif; ?>
                </div>

                <!-- Cover Image -->
                <?php if (!empty($project['coverImage'])): ?>
                    <img src="<?php echo htmlspecialchars($project['coverImage'], ENT_QUOTES, 'UTF-8'); ?>"
                         alt="<?php echo htmlspecialchars($project['title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                         class="projekt-single__cover" fetchpriority="high">
                <?php endif; ?>

                <!-- Content -->
                <div class="projekt-single__content">
                    <?php if (!empty($project['summary'])): ?>
                        <p class="projekt-single__summary"><?php echo htmlspecialchars($project['summary'], ENT_QUOTES, 'UTF-8'); ?></p>
                    <?php endif; ?>

                    <?php if (!empty($project['content'])): ?>
                        <div class="projekt-single__body">
                            <?php echo sanitize_rich_content($project['content']); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Gallery -->
                <?php if (!empty($project['gallery']) && is_array($project['gallery'])): ?>
                    <div class="projekt-single__gallery">
                        <?php foreach ($project['gallery'] as $img): ?>
                            <img src="<?php echo htmlspecialchars($img, ENT_QUOTES, 'UTF-8'); ?>"
                                 alt="<?php echo htmlspecialchars($project['title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                 loading="lazy">
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </article>
    </main>

    <?php include __DIR__ . '/../includes/footer.php'; ?>

    <script src="/assets/js/cms.js?v=<?php echo BOSSE_VERSION; ?>" defer></script>

    <?php if (is_logged_in()): ?>
        <form style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    <?php endif; ?>

    <?php include __DIR__ . '/../includes/cookie-consent.php'; ?>
</body>
</html>
