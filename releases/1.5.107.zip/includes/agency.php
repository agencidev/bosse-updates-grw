<?php
/**
 * Agency branding helper — CORE file
 * Returns agency config with three-tier priority:
 * 1. config.php AGENCY_* constants (per-site override)
 * 2. agency-defaults.json (shipped with update repo, per-partner)
 * 3. Hardcoded Peys defaults (ultimate fallback)
 */

function agency_config(?string $key = null) {
    static $config = null;
    if ($config === null) {
        // 1. Hardcoded defaults
        $defaults = [
            'name'        => 'PEYS',
            'url'         => 'https://peys.se',
            'logo_light'  => '/assets/images/cms/peys-logo-light.png',
            'logo_dark'   => '/assets/images/cms/peys-logo-dark.png',
            'badge_text'  => 'Sidan drivs och hanteras av',
            'badge_bg'    => '#033234',
            'corner_text' => 'Skapad av oss 🥳',
            'login_tab'   => 'PEYS',
        ];

        // 2. agency-defaults.json (from update repo — partner-specific)
        $jsonPath = (defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__)) . '/agency-defaults.json';
        if (file_exists($jsonPath)) {
            $json = json_decode(file_get_contents($jsonPath), true);
            if (is_array($json)) {
                $defaults = array_merge($defaults, $json);
            }
        }

        // 3. config.php overrides (highest priority)
        $map = [
            'name'        => 'AGENCY_NAME',
            'url'         => 'AGENCY_URL',
            'logo_light'  => 'AGENCY_LOGO_LIGHT',
            'logo_dark'   => 'AGENCY_LOGO_DARK',
            'badge_text'  => 'AGENCY_BADGE_TEXT',
            'badge_bg'    => 'AGENCY_BADGE_BG',
            'corner_text' => 'AGENCY_CORNER_TEXT',
            'login_tab'   => 'AGENCY_LOGIN_TAB',
        ];
        $config = $defaults;
        foreach ($map as $k => $const) {
            if (defined($const)) {
                $config[$k] = constant($const);
            }
        }
    }
    return $key !== null ? ($config[$key] ?? null) : $config;
}
