<?php
/**
 * Bosse Analytics — Full analytics dashboard
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../security/session.php';
require_once __DIR__ . '/../includes/version.php';

if (!is_logged_in()) {
    header('Location: /cms/admin.php');
    exit;
}

require_once __DIR__ . '/analytics-db.php';

// Date range
$range = $_GET['range'] ?? '7d';
$now = new DateTime();
$to = $now->format('Y-m-d H:i:s');

switch ($range) {
    case '30d': $from = (clone $now)->modify('-30 days')->format('Y-m-d H:i:s'); break;
    case '90d': $from = (clone $now)->modify('-90 days')->format('Y-m-d H:i:s'); break;
    case 'custom':
        $from = $_GET['from'] ?? (clone $now)->modify('-7 days')->format('Y-m-d');
        $to = ($_GET['to'] ?? $now->format('Y-m-d')) . ' 23:59:59';
        $from .= ' 00:00:00';
        // Sanitize dates
        if (!preg_match('/^\d{4}-\d{2}-\d{2}/', $from)) $from = (clone $now)->modify('-7 days')->format('Y-m-d H:i:s');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}/', $to)) $to = $now->format('Y-m-d H:i:s');
        break;
    default: $from = (clone $now)->modify('-7 days')->format('Y-m-d H:i:s'); $range = '7d'; break;
}

// Previous period for comparison
$fromDt = new DateTime($from);
$toDt = new DateTime($to);
$diff = $fromDt->diff($toDt);
$prevFrom = (clone $fromDt)->modify("-{$diff->days} days")->format('Y-m-d H:i:s');
$prevTo = $fromDt->format('Y-m-d H:i:s');

$overview = analytics_overview($from, $to);
$prevOverview = analytics_overview($prevFrom, $prevTo);
$timeseries = analytics_timeseries($from, $to);
$topPages = analytics_top_pages($from, $to, 10);
$sources = analytics_sources($from, $to, 10);
$deviceData = analytics_devices($from, $to);
$campaigns = analytics_campaigns($from, $to);
$realtime = analytics_realtime();
$visitors = analytics_visitors_timeline(50);
$heatmapPages = analytics_heatmap_pages();

function pct_change(float $current, float $previous): string {
    if ($previous == 0) return $current > 0 ? '+100%' : '0%';
    $change = round(($current - $previous) / $previous * 100, 1);
    return ($change >= 0 ? '+' : '') . $change . '%';
}

function change_class(float $current, float $previous, bool $invert = false): string {
    $diff = $current - $previous;
    if ($invert) $diff = -$diff;
    if ($diff > 0) return 'up';
    if ($diff < 0) return 'down';
    return '';
}

$rangeLabels = ['7d' => '7 dagar', '30d' => '30 dagar', '90d' => '90 dagar', 'custom' => 'Anpassat'];
?>
<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analys - CMS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'DM Sans', sans-serif; background: #033234; min-height: 100vh; color: white; }
        .container { max-width: 64rem; margin: 0 auto; padding: 2rem 1.5rem 4rem; }
        .page-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
        .page-title { font-size: 1.5rem; font-weight: 700; }
        .back-link { color: rgba(255,255,255,0.5); text-decoration: none; font-size: 0.875rem; }
        .back-link:hover { color: rgba(255,255,255,0.8); }

        /* Date picker */
        .date-picker { display: flex; gap: 0.5rem; flex-wrap: wrap; align-items: center; }
        .date-btn { padding: 0.375rem 0.75rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600; border: 1px solid rgba(255,255,255,0.15); background: transparent; color: rgba(255,255,255,0.6); cursor: pointer; transition: all 0.2s; text-decoration: none; }
        .date-btn:hover, .date-btn.active { background: rgba(255,255,255,0.1); color: white; border-color: rgba(255,255,255,0.3); }
        .date-input { padding: 0.375rem 0.5rem; border-radius: 0.375rem; font-size: 0.75rem; border: 1px solid rgba(255,255,255,0.15); background: rgba(255,255,255,0.05); color: white; }

        /* Cards */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 0.75rem; margin-bottom: 1.5rem; }
        .stat-card { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.10); border-radius: 1rem; padding: 1rem; }
        .stat-label { font-size: 0.6875rem; color: rgba(255,255,255,0.45); margin-bottom: 0.25rem; text-transform: uppercase; letter-spacing: 0.03em; }
        .stat-value { font-size: 1.375rem; font-weight: 700; line-height: 1.2; }
        .stat-change { font-size: 0.6875rem; font-weight: 600; margin-top: 0.25rem; }
        .stat-change.up { color: #34d399; }
        .stat-change.down { color: #f87171; }

        /* Panels */
        .panel { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.10); border-radius: 1rem; padding: 1.25rem; margin-bottom: 1rem; }
        .panel-title { font-size: 0.8125rem; font-weight: 600; color: rgba(255,255,255,0.8); margin-bottom: 1rem; }
        .panel-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        @media (max-width: 640px) { .panel-grid { grid-template-columns: 1fr; } }

        /* Chart canvas */
        .chart-wrap { position: relative; height: 12rem; margin-bottom: 0.5rem; }
        .chart-wrap canvas { width: 100% !important; height: 100% !important; }

        /* Tables */
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table th { text-align: left; font-size: 0.6875rem; color: rgba(255,255,255,0.4); text-transform: uppercase; letter-spacing: 0.03em; padding: 0.5rem 0; border-bottom: 1px solid rgba(255,255,255,0.08); }
        .data-table td { font-size: 0.8125rem; color: rgba(255,255,255,0.7); padding: 0.5rem 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
        .data-table td:last-child { text-align: right; font-weight: 600; color: rgba(255,255,255,0.9); }

        /* Bar inline */
        .bar-inline { display: flex; align-items: center; gap: 0.5rem; }
        .bar-track { flex: 1; height: 4px; background: rgba(255,255,255,0.06); border-radius: 9999px; }
        .bar-fill { height: 100%; border-radius: 9999px; background: #379b83; }

        /* Donut legend */
        .donut-wrap { display: flex; align-items: center; gap: 1.5rem; }
        .donut-canvas { width: 100px; height: 100px; flex-shrink: 0; }
        .donut-legend { display: flex; flex-direction: column; gap: 0.375rem; }
        .donut-item { display: flex; align-items: center; gap: 0.5rem; font-size: 0.8125rem; color: rgba(255,255,255,0.7); }
        .donut-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }

        /* Realtime */
        .realtime-card { background: rgba(55,155,131,0.15); border: 1px solid rgba(55,155,131,0.3); border-radius: 1rem; padding: 1rem; margin-bottom: 1rem; display: flex; align-items: center; gap: 1rem; }
        .realtime-dot { width: 10px; height: 10px; border-radius: 50%; background: #34d399; animation: pulse 2s infinite; flex-shrink: 0; }
        @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.4; } }
        .realtime-num { font-size: 1.5rem; font-weight: 700; }
        .realtime-label { font-size: 0.75rem; color: rgba(255,255,255,0.5); }

        /* Visitor timeline */
        .visitor-row { display: flex; align-items: center; gap: 0.75rem; padding: 0.5rem 0; border-bottom: 1px solid rgba(255,255,255,0.05); font-size: 0.8125rem; }
        .visitor-time { color: rgba(255,255,255,0.4); min-width: 4.5rem; font-size: 0.75rem; }
        .visitor-device { color: rgba(255,255,255,0.5); min-width: 4rem; }
        .visitor-pages { color: rgba(255,255,255,0.7); flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        /* Heatmap */
        .heatmap-controls { display: flex; gap: 0.75rem; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; }
        .heatmap-select { padding: 0.375rem 0.5rem; border-radius: 0.375rem; font-size: 0.8125rem; border: 1px solid rgba(255,255,255,0.15); background: rgba(255,255,255,0.05); color: white; max-width: 300px; }
        .heatmap-frame-wrap { position: relative; width: 100%; border-radius: 0.5rem; overflow: hidden; background: white; }
        .heatmap-frame-wrap iframe { width: 100%; height: 500px; border: none; }
        .heatmap-frame-wrap canvas { position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; }
        .opacity-slider { width: 120px; }
        .no-data { color: rgba(255,255,255,0.35); font-size: 0.8125rem; text-align: center; padding: 2rem; }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-bar.php'; ?>
    <div class="container">
        <div class="page-header">
            <div>
                <a href="/dashboard" class="back-link">&larr; Tillbaka</a>
                <h1 class="page-title">Analys</h1>
            </div>
            <div class="date-picker">
                <a href="/analytics?range=7d" class="date-btn <?php echo $range === '7d' ? 'active' : ''; ?>">7d</a>
                <a href="/analytics?range=30d" class="date-btn <?php echo $range === '30d' ? 'active' : ''; ?>">30d</a>
                <a href="/analytics?range=90d" class="date-btn <?php echo $range === '90d' ? 'active' : ''; ?>">90d</a>
                <form method="get" style="display:flex;gap:0.25rem;align-items:center;">
                    <input type="hidden" name="range" value="custom">
                    <input type="date" name="from" class="date-input" value="<?php echo htmlspecialchars(substr($from, 0, 10)); ?>">
                    <span style="color:rgba(255,255,255,0.3);">-</span>
                    <input type="date" name="to" class="date-input" value="<?php echo htmlspecialchars(substr($to, 0, 10)); ?>">
                    <button type="submit" class="date-btn">Visa</button>
                </form>
            </div>
        </div>

        <!-- Realtime -->
        <div class="realtime-card" id="realtime-card">
            <div class="realtime-dot"></div>
            <div>
                <div class="realtime-num" id="rt-count"><?php echo $realtime['active_visitors']; ?></div>
                <div class="realtime-label">aktiva besökare just nu</div>
            </div>
        </div>

        <!-- Overview cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">Besökare</div>
                <div class="stat-value"><?php echo number_format($overview['visitors'], 0, ',', ' '); ?></div>
                <div class="stat-change <?php echo change_class($overview['visitors'], $prevOverview['visitors']); ?>"><?php echo pct_change($overview['visitors'], $prevOverview['visitors']); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Sidvisningar</div>
                <div class="stat-value"><?php echo number_format($overview['pageviews'], 0, ',', ' '); ?></div>
                <div class="stat-change <?php echo change_class($overview['pageviews'], $prevOverview['pageviews']); ?>"><?php echo pct_change($overview['pageviews'], $prevOverview['pageviews']); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Sessions</div>
                <div class="stat-value"><?php echo number_format($overview['sessions'], 0, ',', ' '); ?></div>
                <div class="stat-change <?php echo change_class($overview['sessions'], $prevOverview['sessions']); ?>"><?php echo pct_change($overview['sessions'], $prevOverview['sessions']); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Snitt-tid</div>
                <div class="stat-value"><?php echo gmdate('i:s', (int) $overview['avg_duration']); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Bounce rate</div>
                <div class="stat-value"><?php echo $overview['bounce_rate']; ?>%</div>
                <div class="stat-change <?php echo change_class($overview['bounce_rate'], $prevOverview['bounce_rate'], true); ?>"><?php echo pct_change($overview['bounce_rate'], $prevOverview['bounce_rate']); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Sidor/session</div>
                <div class="stat-value"><?php echo $overview['pages_per_session']; ?></div>
            </div>
        </div>

        <!-- Line chart: Visitors & Pageviews over time -->
        <div class="panel">
            <div class="panel-title">Besökare & sidvisningar</div>
            <div class="chart-wrap"><canvas id="chart-line"></canvas></div>
        </div>

        <!-- Top pages + Sources -->
        <div class="panel-grid">
            <div class="panel">
                <div class="panel-title">Toppsidor</div>
                <?php if (!empty($topPages)): ?>
                <table class="data-table">
                    <thead><tr><th>Sida</th><th>Visningar</th></tr></thead>
                    <tbody>
                    <?php $maxPV = (int) $topPages[0]['views']; foreach ($topPages as $p): ?>
                    <tr>
                        <td>
                            <div class="bar-inline">
                                <span><?php echo htmlspecialchars($p['path']); ?></span>
                            </div>
                        </td>
                        <td><?php echo number_format((int) $p['views'], 0, ',', ' '); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?><div class="no-data">Ingen data</div><?php endif; ?>
            </div>
            <div class="panel">
                <div class="panel-title">Trafikkällor</div>
                <?php if (!empty($sources)):
                    $maxSrc = (int) $sources[0]['sessions'];
                ?>
                <table class="data-table">
                    <thead><tr><th>Källa</th><th>Sessions</th></tr></thead>
                    <tbody>
                    <?php foreach ($sources as $s): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($s['source']); ?></td>
                        <td><?php echo number_format((int) $s['sessions'], 0, ',', ' '); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?><div class="no-data">Ingen data</div><?php endif; ?>
            </div>
        </div>

        <!-- Devices / Browsers / OS -->
        <div class="panel">
            <div class="panel-title">Enheter, webbläsare & OS</div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1.5rem;">
                <div>
                    <div style="font-size:0.75rem;color:rgba(255,255,255,0.4);margin-bottom:0.75rem;">ENHETER</div>
                    <div class="donut-wrap">
                        <canvas id="chart-devices" class="donut-canvas" width="100" height="100"></canvas>
                        <div class="donut-legend" id="legend-devices"></div>
                    </div>
                </div>
                <div>
                    <div style="font-size:0.75rem;color:rgba(255,255,255,0.4);margin-bottom:0.75rem;">WEBBLÄSARE</div>
                    <div class="donut-wrap">
                        <canvas id="chart-browsers" class="donut-canvas" width="100" height="100"></canvas>
                        <div class="donut-legend" id="legend-browsers"></div>
                    </div>
                </div>
                <div>
                    <div style="font-size:0.75rem;color:rgba(255,255,255,0.4);margin-bottom:0.75rem;">OS</div>
                    <div class="donut-wrap">
                        <canvas id="chart-os" class="donut-canvas" width="100" height="100"></canvas>
                        <div class="donut-legend" id="legend-os"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- UTM Campaigns -->
        <?php if (!empty($campaigns)): ?>
        <div class="panel">
            <div class="panel-title">UTM-kampanjer</div>
            <table class="data-table">
                <thead><tr><th>Källa</th><th>Medium</th><th>Kampanj</th><th>Besökare</th><th>Bounce</th></tr></thead>
                <tbody>
                <?php foreach ($campaigns as $c): ?>
                <tr>
                    <td><?php echo htmlspecialchars($c['utm_source']); ?></td>
                    <td><?php echo htmlspecialchars($c['utm_medium']); ?></td>
                    <td><?php echo htmlspecialchars($c['utm_campaign']); ?></td>
                    <td><?php echo (int) $c['visitors']; ?></td>
                    <td><?php echo round((float) $c['bounce_rate']); ?>%</td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <!-- Visitor timeline -->
        <div class="panel">
            <div class="panel-title">Senaste besökare</div>
            <?php if (!empty($visitors)): ?>
            <div style="max-height:25rem;overflow-y:auto;">
                <?php foreach ($visitors as $v): ?>
                <div class="visitor-row">
                    <span class="visitor-time"><?php echo htmlspecialchars(substr($v['started_at'], 5, 11)); ?></span>
                    <span class="visitor-device"><?php echo htmlspecialchars($v['device_type'] ?? ''); ?></span>
                    <span class="visitor-pages"><?php echo htmlspecialchars($v['pages'] ?? $v['landing_page'] ?? ''); ?></span>
                    <span style="color:rgba(255,255,255,0.4);font-size:0.75rem;min-width:3rem;text-align:right;"><?php echo (int) ($v['page_count'] ?? 0); ?>s</span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?><div class="no-data">Inga besökare ännu</div><?php endif; ?>
        </div>

        <!-- Heatmap viewer -->
        <div class="panel">
            <div class="panel-title">Heatmap</div>
            <?php if (!empty($heatmapPages)): ?>
            <div class="heatmap-controls">
                <select id="heatmap-page" class="heatmap-select">
                    <?php foreach ($heatmapPages as $hp): ?>
                    <option value="<?php echo htmlspecialchars($hp['path']); ?>"><?php echo htmlspecialchars($hp['path']); ?> (<?php echo (int) $hp['clicks']; ?> klick)</option>
                    <?php endforeach; ?>
                </select>
                <label style="font-size:0.75rem;color:rgba(255,255,255,0.5);">Opacitet:
                    <input type="range" id="heatmap-opacity" class="opacity-slider" min="10" max="100" value="60">
                </label>
                <button id="heatmap-load" class="date-btn">Visa heatmap</button>
            </div>
            <div class="heatmap-frame-wrap" id="heatmap-wrap" style="display:none;">
                <iframe id="heatmap-iframe"></iframe>
                <canvas id="heatmap-canvas"></canvas>
            </div>
            <?php else: ?><div class="no-data">Inga klick registrerade ännu</div><?php endif; ?>
        </div>
    </div>

    <?php include __DIR__ . '/../includes/agenci-badge.php'; ?>

    <script <?php echo csp_nonce_attr(); ?>>
    // ── Data from PHP ──
    var tsData = <?php echo json_encode($timeseries); ?>;
    var devicesData = <?php echo json_encode($deviceData['devices']); ?>;
    var browsersData = <?php echo json_encode($deviceData['browsers']); ?>;
    var osData = <?php echo json_encode($deviceData['os']); ?>;
    var COLORS = ['#379b83','#34d399','#fbbf24','#f87171','#818cf8','#fb923c','#a78bfa','#38bdf8'];

    // ── BosseChart: minimal canvas charts ──
    var BosseChart = {
        line: function(canvasId, data, keys, labels) {
            var canvas = document.getElementById(canvasId);
            if (!canvas || !data.length) return;
            var ctx = canvas.getContext('2d');
            var dpr = window.devicePixelRatio || 1;
            var rect = canvas.parentElement.getBoundingClientRect();
            canvas.width = rect.width * dpr;
            canvas.height = rect.height * dpr;
            ctx.scale(dpr, dpr);
            var W = rect.width, H = rect.height;
            var pad = {t:10,r:10,b:25,l:40};
            var cW = W - pad.l - pad.r, cH = H - pad.t - pad.b;

            // Find max
            var maxVal = 1;
            keys.forEach(function(k) {
                data.forEach(function(d) { if (d[k] > maxVal) maxVal = d[k]; });
            });

            keys.forEach(function(key, ki) {
                var color = COLORS[ki];
                ctx.beginPath();
                data.forEach(function(d, i) {
                    var x = pad.l + (i / Math.max(data.length - 1, 1)) * cW;
                    var y = pad.t + cH - (d[key] / maxVal) * cH;
                    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
                });
                ctx.strokeStyle = color;
                ctx.lineWidth = 2;
                ctx.stroke();

                // Area fill
                var lastX = pad.l + ((data.length - 1) / Math.max(data.length - 1, 1)) * cW;
                ctx.lineTo(lastX, pad.t + cH);
                ctx.lineTo(pad.l, pad.t + cH);
                ctx.closePath();
                ctx.fillStyle = color.replace(')', ',0.1)').replace('rgb', 'rgba');
                ctx.globalAlpha = 0.3;
                ctx.fill();
                ctx.globalAlpha = 1;
            });

            // X-axis labels
            ctx.fillStyle = 'rgba(255,255,255,0.3)';
            ctx.font = '10px DM Sans, sans-serif';
            ctx.textAlign = 'center';
            var step = Math.max(1, Math.floor(data.length / 7));
            for (var i = 0; i < data.length; i += step) {
                var x = pad.l + (i / Math.max(data.length - 1, 1)) * cW;
                ctx.fillText(data[i].day.substring(5), x, H - 5);
            }

            // Y-axis labels
            ctx.textAlign = 'right';
            for (var j = 0; j <= 4; j++) {
                var val = Math.round(maxVal * j / 4);
                var y = pad.t + cH - (j / 4) * cH;
                ctx.fillText(val, pad.l - 5, y + 3);
                // Grid line
                ctx.strokeStyle = 'rgba(255,255,255,0.05)';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(pad.l, y);
                ctx.lineTo(W - pad.r, y);
                ctx.stroke();
            }

            // Legend
            ctx.textAlign = 'left';
            keys.forEach(function(key, ki) {
                ctx.fillStyle = COLORS[ki];
                ctx.fillRect(pad.l + ki * 100, 2, 12, 3);
                ctx.fillStyle = 'rgba(255,255,255,0.5)';
                ctx.fillText(labels[ki], pad.l + ki * 100 + 16, 8);
            });
        },

        donut: function(canvasId, legendId, data, labelKey, valueKey) {
            var canvas = document.getElementById(canvasId);
            var legend = document.getElementById(legendId);
            if (!canvas || !data.length) return;
            var ctx = canvas.getContext('2d');
            var dpr = window.devicePixelRatio || 1;
            canvas.width = 100 * dpr;
            canvas.height = 100 * dpr;
            ctx.scale(dpr, dpr);

            var total = 0;
            data.forEach(function(d) { total += parseInt(d[valueKey]) || 0; });
            if (total === 0) return;

            var cx = 50, cy = 50, r = 40, inner = 25;
            var startAngle = -Math.PI / 2;

            var html = '';
            data.forEach(function(d, i) {
                var val = parseInt(d[valueKey]) || 0;
                var slice = (val / total) * Math.PI * 2;
                var endAngle = startAngle + slice;
                var color = COLORS[i % COLORS.length];

                ctx.beginPath();
                ctx.arc(cx, cy, r, startAngle, endAngle);
                ctx.arc(cx, cy, inner, endAngle, startAngle, true);
                ctx.closePath();
                ctx.fillStyle = color;
                ctx.fill();

                html += '<div class="donut-item"><span class="donut-dot" style="background:' + color + '"></span>' +
                    (d[labelKey] || 'Okänd') + ' <span style="color:rgba(255,255,255,0.4)">' + Math.round(val/total*100) + '%</span></div>';

                startAngle = endAngle;
            });
            if (legend) legend.innerHTML = html;
        }
    };

    // Render charts
    BosseChart.line('chart-line', tsData, ['visitors','pageviews'], ['Besökare','Sidvisningar']);
    BosseChart.donut('chart-devices', 'legend-devices', devicesData, 'device_type', 'cnt');
    BosseChart.donut('chart-browsers', 'legend-browsers', browsersData, 'browser', 'cnt');
    BosseChart.donut('chart-os', 'legend-os', osData, 'os', 'cnt');

    // ── Realtime auto-refresh ──
    setInterval(function() {
        fetch('/cms/api.php?action=analytics-realtime')
            .then(function(r) { return r.json(); })
            .then(function(d) {
                if (d.success) {
                    document.getElementById('rt-count').textContent = d.data.active_visitors;
                }
            }).catch(function(){});
    }, 15000);

    // ── Heatmap ──
    var hmBtn = document.getElementById('heatmap-load');
    if (hmBtn) {
        hmBtn.addEventListener('click', function() {
            var path = document.getElementById('heatmap-page').value;
            var wrap = document.getElementById('heatmap-wrap');
            var iframe = document.getElementById('heatmap-iframe');
            var canvas = document.getElementById('heatmap-canvas');

            wrap.style.display = 'block';
            iframe.src = path + (path.indexOf('?') >= 0 ? '&' : '?') + '_heatmap=1';

            iframe.onload = function() {
                // Fetch heatmap data
                fetch('/cms/api.php?action=analytics-heatmap&path=' + encodeURIComponent(path))
                    .then(function(r) { return r.json(); })
                    .then(function(d) {
                        if (!d.success || !d.data.clicks.length) return;
                        renderHeatmap(canvas, d.data.clicks, d.data.aggregated);
                    }).catch(function(){});
            };
        });

        var opSlider = document.getElementById('heatmap-opacity');
        if (opSlider) {
            opSlider.addEventListener('input', function() {
                var canvas = document.getElementById('heatmap-canvas');
                canvas.style.opacity = this.value / 100;
            });
        }
    }

    function renderHeatmap(canvas, clicks, aggregated) {
        var wrap = canvas.parentElement;
        var W = wrap.clientWidth;
        var H = wrap.clientHeight;
        var dpr = window.devicePixelRatio || 1;
        canvas.width = W * dpr;
        canvas.height = H * dpr;
        var ctx = canvas.getContext('2d');
        ctx.scale(dpr, dpr);

        // Draw radial gradients
        clicks.forEach(function(c) {
            var x = (c.x / 100) * W;
            var y = (c.y / 100) * H;
            var intensity = aggregated ? Math.min((c.count || 1) / 10, 1) : 0.3;
            var radius = 20 + intensity * 20;

            var grad = ctx.createRadialGradient(x, y, 0, x, y, radius);
            grad.addColorStop(0, 'rgba(255, 0, 0, ' + (0.3 + intensity * 0.4) + ')');
            grad.addColorStop(0.5, 'rgba(255, 165, 0, ' + (0.15 + intensity * 0.15) + ')');
            grad.addColorStop(1, 'rgba(0, 0, 255, 0)');

            ctx.fillStyle = grad;
            ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);
        });

        canvas.style.opacity = document.getElementById('heatmap-opacity').value / 100;
    }
    </script>
</body>
</html>
